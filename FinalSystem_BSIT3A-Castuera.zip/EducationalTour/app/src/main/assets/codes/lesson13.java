

public void doSomething() {
	// some codes to run here
}

private int add(int a, int b) {
	int answer = a + b;
	return answer;
}

protected boolean isEarthRound() {
	// codes to figure out if the earth is actually round
	boolean maybe;
	if(some people say it is) {
		maybe = true;
	} else if (some people say it is not){
		maybe = false;
	}
	
	return maybe
}
